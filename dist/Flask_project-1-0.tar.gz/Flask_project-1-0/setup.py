from setuptools import setup, find_packages

setup(
    name='Flask_project',
    version='1,0',
    author='Anton Levchuk',
    author_email='insanelev@gmail.com',
    packages=find_packages()
)
