from Flask_project import db, login_manager

from werkzeug.security import generate_password_hash, check_password_hash

from flask_login import UserMixin


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(user_id)


class User(db.Model, UserMixin):
    """ User model """

    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(64), unique=True, index=True)
    username = db.Column(db.String(64), unique=True, index=True)
    password_hash = db.Column(db.String(128))

    def __init__(self, email, username, password):
        self.email = email
        self.username = username
        self.password_hash = generate_password_hash(password)

    def __repr__(self):
        return f'{self.email}, {self.username}'

    def check_password(self, password):
        """ The func which is checking your password """

        return check_password_hash(self.password_hash, password)


class Artists(db.Model):
    """ Artist's model """

    __tablename__ = 'artists'

    id = db.Column(db.Integer, nullable=False, primary_key=True)
    artist_id = db.Column(db.String(128), nullable=False, unique=True)
    artist_name = db.Column(db.String(128), nullable=False, unique=True)
    genres = db.Column(db.String(128), nullable=False)
    artist_url = db.Column(db.String(128), nullable=False)
    artist_img_url = db.Column(db.String(128), nullable=False)
    about_artists = db.Column(db.Text)

    def __init__(self, artist_id, artist_name, genres, artist_url, artist_img_url, about_artists):
        self.artist_id = artist_id
        self.artist_name = artist_name
        self.genres = genres
        self.artist_url = artist_url
        self.artist_img_url = artist_img_url
        self.about_artists = about_artists

    def __repr__(self):
        return f"Artist id: {self.artist_id}, artist's name: {self.artist_name}"


class Tracks(db.Model):
    """ Track's model """

    __tablename__ = 'tracks'

    id = db.Column(db.Integer, nullable=False, primary_key=True)
    artist_name = db.Column(db.String(64), nullable=False)
    album_name = db.Column(db.String(64), nullable=False)
    track_name = db.Column(db.String(64), nullable=False, unique=True)
    track_img_url = db.Column(db.String(128), nullable=False)
    release_date = db.Column(db.Date, nullable=False)
    track_url = db.Column(db.String(128), nullable=False)

    def __init__(self, artist_name, album_name, track_name, track_img_url, release_date, track_url):
        self.artist_name = artist_name
        self.album_name = album_name
        self.track_name = track_name
        self.track_img_url = track_img_url
        self.release_date = release_date
        self.track_url = track_url

    def __repr__(self):
        return f" Track: {self.track_name}, artist's name: {self.artist_name}"
