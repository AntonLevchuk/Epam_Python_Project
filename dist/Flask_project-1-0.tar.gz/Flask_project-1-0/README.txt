########################################################################################################################
Hello there
Here you will find how to use different files in this app and for what they need.
########################################################################################################################

This application is displaying top charts from Spotify and top artists. You can read interesting info about them and
about their genres, so if you liked some of them you can listen their on Spotify, push on "Listen on Spotify" button.

########################################################################################################################
app.py

There you will find routes and the run() function which runs the local server with this application.
########################################################################################################################
Flask_project/models.py

There you can find the models of Users, Artists and Tracks.
########################################################################################################################
Flask_project/__init__.py

There you will find the configuration of this app, so if you want to change some 'settings' you need to go there.
########################################################################################################################
Flask_project/forms.py

There you will find the registration and login forms.
########################################################################################################################
Flask_project/rest/Refreshing_Access_Token.py

In this file implemented refreshing of the access token to Spotify API and getting of the access token, so if you want
to add some functionality to this application which connected with Spotify API, firstly you need to get the access
token with permission. You need to refresh this token every hour.
########################################################################################################################
Flask_project/rest/Users_Top_Item.py

There you will find the API requests for Top Artists and Top Tracks in CIS region. You will find there the
'get_info()' function which scraping 'genius.com' and saving some information about artists. Also, you will find there
the script which save the info about artists to db.
########################################################################################################################
In  Flask_project/templates you will find the HTML templates of this app.

In Flask_project/static/css you will find the CSS styles if the HTML templates.

In requirements.txt you will find the modules which were used in this app
########################################################################################################################

Thank you for your attention!
